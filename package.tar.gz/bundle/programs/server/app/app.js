var require = meteorInstall({"lib":{"router.js":["meteor/http",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// lib/router.js                                                     //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var HTTP = void 0;                                                   // 1
module.importSync("meteor/http", {                                   // 1
    HTTP: function (v) {                                             // 1
        HTTP = v;                                                    // 1
    }                                                                // 1
}, 0);                                                               // 1
Router.route('/', function () {                                      // 6
    this.render('MainPage');                                         // 7
});                                                                  // 8
Router.route('/player', function () {                                // 10
    this.render('player');                                           // 11
});                                                                  // 12
///////////////////////////////////////////////////////////////////////

}]},"api":{"methods.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// api/methods.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
// Meteor Methods                                                    // 1
///////////////////////////////////////////////////////////////////////

}},"server":{"newuser.js":function(){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/newuser.js                                                 //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
Accounts.onCreateUser(function (options, user) {                     // 1
    user.profile['likes'] = [];                                      // 2
    user.profile['dislikes'] = [];                                   // 3
    return user;                                                     // 4
});                                                                  // 5
///////////////////////////////////////////////////////////////////////

},"main.js":["meteor/meteor",function(require,exports,module){

///////////////////////////////////////////////////////////////////////
//                                                                   //
// server/main.js                                                    //
//                                                                   //
///////////////////////////////////////////////////////////////////////
                                                                     //
var Meteor = void 0;                                                 // 1
module.importSync("meteor/meteor", {                                 // 1
  Meteor: function (v) {                                             // 1
    Meteor = v;                                                      // 1
  }                                                                  // 1
}, 0);                                                               // 1
Videos = new Mongo.Collection('videos');                             // 5
Meteor.startup(function () {                                         // 8
  // code to run on server at startup                                // 9
  // Clean database                                                  // 10
  Meteor.users.remove({});                                           // 11
  Accounts.removeOldGuests();                                        // 12
  ;                                                                  // 12
  AccountsGuest.anonymous = true;                                    // 13
  AccountsGuest.name = true;                                         // 14
  Videos.remove({});                                                 // 15
});                                                                  // 16
///////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./lib/router.js");
require("./api/methods.js");
require("./server/newuser.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
