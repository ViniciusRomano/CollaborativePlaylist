(function () {

/* Package-scope variables */
var AccountsPatchUi;



/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['brettle:accounts-patch-ui'] = {}, {
  AccountsPatchUi: AccountsPatchUi
});

})();
