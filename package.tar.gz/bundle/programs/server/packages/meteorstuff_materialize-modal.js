(function () {

/* Package-scope variables */
var MaterializeModal;



/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['meteorstuff:materialize-modal'] = {}, {
  MaterializeModal: MaterializeModal
});

})();
